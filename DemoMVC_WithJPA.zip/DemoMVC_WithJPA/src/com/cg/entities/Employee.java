package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="emp_157")
public class Employee {
@Id
@Column(name="emp_no")
@NotNull(message="EmpNo is Mandatory")
private Integer empNo;

@Column(name="emp_name")
@NotEmpty(message="Name is Mandatory")
@Pattern(regexp="[A-Za-z]{3,15}",message="Name Sould contain 3 and max 15 letters")
private String empName;
@Column(name="emp_age")
@NotNull(message="Age is Mandatory")
private Integer empAge;
@Override
public String toString() {
	return "Employee [empNo=" + empNo + ", empName=" + empName + ", empAge="
			+ empAge + "]";
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(Integer empNo, String empName, Integer empAge) {
	super();
	this.empNo = empNo;
	this.empName = empName;
	this.empAge = empAge;
}
public Integer getEmpNo() {
	return empNo;
}
public void setEmpNo(Integer empNo) {
	this.empNo = empNo;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public Integer getEmpAge() {
	return empAge;
}
public void setEmpAge(Integer empAge) {
	this.empAge = empAge;
}

}
