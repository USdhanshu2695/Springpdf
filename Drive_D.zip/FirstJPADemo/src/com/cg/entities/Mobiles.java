package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="Mobiles")
@NamedQueries(@NamedQuery(name="getMobiles",
query="Select m from Mobiles m WHERE m.quantity>:qty"))
public class Mobiles {
@Id
@Column(name="mobileId")
@SequenceGenerator(name="myseq",sequenceName="seq_mobiles",allocationSize=1)
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="myseq")
private int mobileId;

@Column(name="NAME")
private String mobileName;

@Column(name="PRICE")
private double price;
@Column(name="quantity")
private int quantity;
@Override
public String toString() {
	return "Mobiles [mobileId=" + mobileId + ", mobileName=" + mobileName
			+ ", price=" + price + ", quantity=" + quantity + "]";
}

public Mobiles() {
	super();
	// TODO Auto-generated constructor stub
}

public Mobiles(int mobileId, String mobileName, double price, int quantity) {
	super();
	this.mobileId = mobileId;
	this.mobileName = mobileName;
	this.price = price;
	this.quantity = quantity;
}

public int getMobileId() {
	return mobileId;
}

public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}

public String getMobileName() {
	return mobileName;
}

public void setMobileName(String mobileName) {
	this.mobileName = mobileName;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}




}
