package com.cg.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entities.Mobiles;

public class MobileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em= emf.createEntityManager();
Scanner sc =new Scanner(System.in);
//Mobiles mob=em.find(Mobiles.class, 1001);
//System.out.println(mob);
	
Mobiles mob= new Mobiles()	;
System.out.println("Enter Mobile name:");
mob.setMobileName(sc.next());
System.out.println("Enter  price of Mobile:");
mob.setPrice(sc.nextDouble());
System.out.println("Enter Mobile quantity:");
mob.setQuantity(sc.nextInt());
em.getTransaction().begin();
em.persist(mob);
em.getTransaction().commit();
System.out.println("Mobile details inserted...");

	}

}
