package com.cg.ui;


import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;




import com.cg.entities.Mobiles;

public class MobileQueries {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
	//	em.getTransaction().begin();
		Scanner sc =new Scanner(System.in);
		//String jpql="Select m from Mobiles m WHERE m.quantity>:qty";
		TypedQuery<Mobiles> query=em.createNamedQuery("getMobiles", Mobiles.class);
		query.setParameter("qty",5);
		List<Mobiles> mlist=query.getResultList();
		
		for(Mobiles m :mlist){
			System.out.println(m);
		}

	}

}
