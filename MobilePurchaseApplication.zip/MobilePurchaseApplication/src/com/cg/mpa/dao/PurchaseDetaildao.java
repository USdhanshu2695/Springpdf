package com.cg.mpa.dao;

import com.cg.mpa.entities.PurchaseDetails;

public interface PurchaseDetaildao {
void insertPurchaseDetails(PurchaseDetails pdetails);
}
