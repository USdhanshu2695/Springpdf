package com.cg.mpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mpa.dao.MobileDao;
import com.cg.mpa.dao.PurchaseDetaildao;
import com.cg.mpa.entities.Mobile;
import com.cg.mpa.entities.PurchaseDetails;
@Service
@Transactional
public class MobilePurchaseServiceImpl  implements MobilePurchaseService{
	
	@Autowired
	MobileDao mdao;
	@Autowired
	PurchaseDetaildao pdao;
	@Override
	public List<Mobile> getAllMobiles() {
		// TODO Auto-generated method stub
		return mdao.fetchAllMobiles();
	}

	@Override
	public void insertPurchaseDeatils(PurchaseDetails pdetails) {
		// TODO Auto-generated method stub
		pdao.insertPurchaseDetails(pdetails);
	}

}
