package com.cg.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;



import com.cg.entities.Trainee;
import com.cg.service.TraineeService;



public class TraineeController  {



		@Autowired
		TraineeService tser;
		
		
		@RequestMapping("welcome")
		public String showMessage(@RequestParam("uname")String uname,@RequestParam("pwd")String pwd,Model model){
			String name="Sudhanshu";
			String pass="Ramram123"	;
			if((name.equalsIgnoreCase(uname)) &&(pass.equals(pwd)))
			{	//1:key 2:value
			//add component in the model
			return "TMS";
			}
			else{
				return "Index";
			}
		}//welcome.jsp
		@RequestMapping("inserting")
		public String showInsertPage(Model model){
				model.addAttribute("trn",new Trainee());
				return "insert";
			}
		@RequestMapping("insert")
		public String insertEmp(@Valid @ModelAttribute("trn") Trainee trn,BindingResult res,Model model){
			if(res.hasErrors()){
				model.addAttribute("trn", trn);
				return "insert";
			}else{
				//call service layer method
				tser.insertTrainee(trn);
				model.addAttribute("trn", trn);
				return "success";
			}	
		}
		
	}