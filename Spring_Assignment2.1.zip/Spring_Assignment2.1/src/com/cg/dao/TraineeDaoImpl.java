/*package com.cg.dao;

import com.cg.entities.Trainee;

public class TraineeDaoImpl implements TraineeDao {

	@Override
	public int insertTrainee(Trainee trn) {
		// TODO Auto-generated method stub
		return 0;
	}

}
*/