package com.cg.service;

import com.cg.entities.Trainee;

public interface TraineeService {
	int insertTrainee(Trainee trn);
}
