package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.cg.dao.TraineeDao;
import com.cg.entities.Trainee;

@Service("eser")
@Transactional
public class TraineeServiceImpl implements TraineeService {

		@Autowired
	TraineeDao tdao;//loose coupling only name of interface
		
		@Override
		public int insertTrainee(Trainee trn) {
			tdao.save(trn);
			return trn.getTraineeId();
		}
	}

	
