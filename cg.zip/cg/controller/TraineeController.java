package com.cg.controller;



import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;




import com.cg.entities.Trainee;
import com.cg.service.TraineeService;


@Controller
public class TraineeController  {



		@Autowired
		TraineeService tser;
		
		Trainee tdetails1 = null;
		@RequestMapping("welcome")//mapping of the uri
		public String showMessage(@RequestParam("uname")String uname,@RequestParam("pwd")String pwd,Model model){
			//getting the input from the  page by using model attribute
			String name="Sudhanshu";
			String pass="Ramram123"	;
			
			if((name.equalsIgnoreCase(uname)) &&(pass.equals(pwd)))
			{	
			
			return "TMS";//return to a jsp page
			}
			else{
				return "Index1";//return  to a jsp page
			}
		}
		@RequestMapping("inserting")//mapping of the uri
		public String showInsertPage(Model model){
				model.addAttribute("trn",new Trainee());//add component in the model,the object can now be accessed by the jsp page
				return "insert";//return a jsp page
			}
		@RequestMapping("insert")//mapping of the uri
		public String insertEmp(@Valid @ModelAttribute("trn") Trainee trn,BindingResult res,Model model){
			if(res.hasErrors())//if input has any errors
				
			{
				model.addAttribute("trn", trn);//add component in the model,the object can now be accessed by the jsp page
				return "insert";//return a jsp page
			}else{
				
				tser.insertTrainee(trn);//calls the service layer method to insert Traineee
				model.addAttribute("trn", trn);//add component in the model,the object can now be accessed by the jsp page
				return "success";//return a jsp page
			}	
		}
		@RequestMapping("delete")//mapping of the uri
		public String showDeletePage(Model model){
			
			return "delete";//return a jsp page
		}
		@RequestMapping("delete1")//mapping of the uri
		public String showMessage1(@RequestParam("traineeID")Integer traineeID,Model model){
			//getting the input from the textbox
			tdetails1=tser.getTrainees(traineeID);//calls the service layer method to get trainee object belonging to the traineeID
		
			model.addAttribute("tdetails", tdetails1);//add component in the model,the object can now be accessed by the jsp page
	
			return "traineeinfo";//return a jsp page
}
		
		@RequestMapping("delete2")//mapping of the uri

		public String showPurchasePage(@ModelAttribute("tdetails")Trainee trainee,BindingResult res,Model model){
			//gets the object from  jsp page by using model attribute
			
			if(res.hasErrors())
			{return "traineeinfo";//return a jsp page
			}
			
			else{
				
			tser.deleteTrainee(trainee.getTraineeId());//calls the service layer method to delete a trainee 
			return "success";
			}
		}
		@RequestMapping("modify")//mapping of the uri
		public String showModifyPage(Model model){
			
			return "modify";//return a jsp page
		}
		@RequestMapping("modify1")//mapping of the uri
		public String showModifyPage1(@RequestParam("modify")Integer modify,Model model){
			//getting the input from the textbox

			
		Trainee mlist=tser.getTrainees(modify);//calls the service layer method to get trainee object belonging to the traineeID
	
		model.addAttribute("mlist", mlist);//add component in the model,the object can now be accessed by the jsp page
	
		return "traineeinfo1";//return a jsp page
			
		}
		@RequestMapping("modify2")//mapping of the uri
		public String showModifiedPage(@ Valid @ModelAttribute("mlist")Trainee trainee,BindingResult res,Model model){
			//gets the object from  jsp page by using model attribute

			if(res.hasErrors())//checks for any errors 
			{return "traineeinfo1";}//return a jsp page
			else{
			
			tser.modifyTrainee(trainee);//calls the service layer method to modify the trainee details
			model.addAttribute("trn", trainee);//add component in the model,the object can now be accessed by the jsp page

			return "success";//return a jsp page
			}
		}
		@RequestMapping("retrieve")//mapping of the uri
public String showPage(Model model){
			
			return "retrieve";//return a jsp page
		}
		@RequestMapping("retrieve1")//mapping of the uri
		public String showPage2(@RequestParam("traineeID")Integer traineeID,Model model){
			//getting the input from the textbox
			 Trainee tdetails=tser.getTrainees(traineeID);//calls the service layer method
		
			model.addAttribute("tdetails", tdetails);//add component in the model,the object can now be accessed by the jsp page
	
			return "traineeinfo2";
				}
		@RequestMapping("retrieveAll")//mapping of the uri
		public String showPagefdsa(Model model){
					
					
				
			
					 List<Trainee> mlist=tser.getAllTrainee();//calls the service layer method which returns a list of all the trainees
						model.addAttribute("mlist", mlist);//add component in the model,the object can now be accessed by the jsp page
					
			
					return "traineeinfo3";//return a jsp page
						}
		
}