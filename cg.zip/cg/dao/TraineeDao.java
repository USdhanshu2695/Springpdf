package com.cg.dao;

import java.util.List;








import com.cg.entities.Trainee;






public interface TraineeDao {
	void insertTrainee(Trainee tdetails);
	Trainee fetchTrainee(Integer traineeId);
	//List<Mobile> fetchAllMobiles();
	void deleteTrainee(Integer traineeId);
	void modifyTrainee(Trainee mob);
	List<Trainee> fetchAllMobiles();


}
