package com.cg.dao;





import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Trainee;


@Repository
@Transactional
public class TraineeDaoImpl implements TraineeDao {

	
	@PersistenceContext
	private EntityManager em;
	@Override
	public void insertTrainee(Trainee tdetails) {
		// TODO Auto-generated method stub
		em.persist(tdetails);
	}
	@Override
	public Trainee fetchTrainee(Integer tId) {
		Trainee mobil=em.find(Trainee.class, tId);
		return mobil;
	}
/*	@Override
	public List<Mobile> fetchAllMobiles() {
		String jpql="SELECT m FROM Mobile m";//same as class name
				TypedQuery<Mobile> query=em.createQuery(jpql,Mobile.class);
		return query.getResultList();
	}*/
	@Override
	public void deleteTrainee(Integer traineeId) {
		// TODO Auto-generated method stub
		Trainee mobile=em.find(Trainee.class,traineeId);
		em.remove(mobile);
	}
	@Override
	public void modifyTrainee(Trainee mob) {
		
		em.merge(mob);
	}
	@Override
	public List<Trainee> fetchAllMobiles() {
		String jpql="SELECT m FROM Trainee m";//same as class name
		TypedQuery<Trainee> query=em.createQuery(jpql,Trainee.class);
return query.getResultList();
	}

}
