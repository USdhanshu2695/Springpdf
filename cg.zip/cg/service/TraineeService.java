package com.cg.service;

import java.util.List;

import com.cg.entities.Trainee;



public interface TraineeService {
	void insertTrainee(Trainee tdetails);
	 Trainee getTrainees(Integer tId);
	void deleteTrainee(Integer traineeId);
	void modifyTrainee(Trainee mob);
	List <Trainee>getAllTrainee();


}
