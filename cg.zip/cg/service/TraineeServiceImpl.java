package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;





import com.cg.dao.TraineeDao;
import com.cg.entities.Trainee;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

		@Autowired
	TraineeDao tdao;//loose coupling only name of interface

		@Override
		public void insertTrainee(Trainee tdetails) {
			tdao.insertTrainee(tdetails);
			
		}

		@Override
		public Trainee getTrainees(Integer tId) {
			return tdao.fetchTrainee(tId);
		}

		@Override
		public void deleteTrainee(Integer traineeId) {
		 tdao.deleteTrainee(traineeId);
			
		}

		@Override
		public void modifyTrainee(Trainee mob) {
			tdao.modifyTrainee(mob);
			
		}

		@Override
		public List<Trainee> getAllTrainee() {
			// TODO Auto-generated method stub
			return tdao.fetchAllMobiles();
		}

		
		
	
		
		}
	

	
